
# Verifikasi World ID untuk Bangsa World 🌍

Aplikasi ini memungkinkan pengguna melakukan verifikasi dengan Worldcoin (World ID).

## Cara Jalankan
1. `npm install`
2. `npm run dev`
3. Buka `http://localhost:3000`
